function love.conf(t)
    t.window.title = "Harmoni Rewrite 0.1.0"

    t.window.width = 1280
    t.window.height = 720
    t.console = true

    t.window.resizable = true
    t.window.vsync = 0
end 