return {
    -- Game base resolution
    GameWidth = 1280,
    GameHeight = 720,

    -- Window base resolution
    WindowWidth = 1280,
    WindowHeight = 720,
}