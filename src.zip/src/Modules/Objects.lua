return {
    Game = {
        Note = require("Objects.Game.Note"),
        Receptor = require("Objects/Game.Receptor"),
    }
}