return {
    Game = {
        PlayState = require("States.Game.Playstate"),
    },
    Menu = {
        SongSelect = require("States.Menu.SongSelect"),
    }
}