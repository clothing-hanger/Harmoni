return {
    --Test = love.graphics.newShader("Shaders/Test.glsl"),

    CurrentShader = nil
}